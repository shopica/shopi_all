package com.example.braintrainer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;

public class ThirdActivity extends AppCompatActivity {
    TextView result,ques,total,correct,wrong,timer;
    Button   op1,op2,op3,op4;
    Random  randomno,randques;
    int o,th,q1,q2,ans,var =0,re = 0,wr = 0,duration =1000;


    CountDownTimer count = new CountDownTimer(60000,1000) {
        @Override
        public void onTick(long millisUntilFinished) {

            changeText((int)millisUntilFinished/1000);


        }

        @Override
        public void onFinish() {

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {

                    Intent back = new Intent(ThirdActivity.this,SecondActivity.class);
                    startActivity(back);
                    finish();

                }
            },duration);

        }
    }.start();

    public void changeText(int time){
        timer = (TextView)findViewById(R.id.timer);
        timer.setText(Integer.toString(time)+"s");


    }


    public void genques(){
        randques = new Random();
        q1 = randques.nextInt(50);
        q2 = randques.nextInt(50);
        ArrayList<Integer> arr = new ArrayList<Integer>();

        ques = (TextView)findViewById(R.id.ques);

        ques.setText(Integer.toString(q1)+" + "+Integer.toString(q2));
        th =  q1+q2;

        randomno = new Random();
        ans = randques.nextInt(4);
        for(int i=0;i<4;i++){
            if(i == ans){
                arr.add(th);
            }
            else{
                o = randomno.nextInt(100-20)+20;
                while(th == o){
                    o = randomno.nextInt(100-20)+20;
                }
                arr.add(o);
            }

        }
        op1 = (Button)findViewById(R.id.op1);
        op2 = (Button)findViewById(R.id.op2);
        op3 = (Button)findViewById(R.id.op3);
        op4 = (Button)findViewById(R.id.op4);

        op1.setText(Integer.toString(arr.get(0)));
        op2.setText(Integer.toString(arr.get(1)));
        op3.setText(Integer.toString(arr.get(2)));
        op4.setText(Integer.toString(arr.get(3)));


    }




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.third);
        result = (TextView)findViewById(R.id.result);
        result.setVisibility(View.INVISIBLE);
        genques();

    }


    public void clicked(View view){
        result = (TextView)findViewById(R.id.result);

        if(Integer.toString(ans).equals(view.getTag().toString())){

            result.setText("Good job!");

            re++;





        }
        else{
            result.setText("OOPS,Wrong!");

            wr++;

        }
        result.setVisibility(View.VISIBLE);
        total = (TextView)findViewById(R.id.total);
        var++;
        total.setText(Integer.toString(var));
        correct = (TextView)findViewById(R.id.correct);
        wrong = (TextView)findViewById(R.id.wrong);
        correct.setText(Integer.toString(re));
        wrong.setText(Integer.toString(wr));

        genques();


    }

}
