package com.example.weatherapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    EditText edit;
    TextView tempera;
    TextView pressu;
    TextView humi;
    TextView windu;
    TextView descrip;
    ImageView back;
    Button go;


    public class DownloadJasonData extends AsyncTask<String,Void,String>{

        @Override
        protected String doInBackground(String... urls) {

            String result = "";
            URL url;
            HttpURLConnection connection;

            try {
                 url = new URL(urls[0]);
                 connection = (HttpURLConnection)url.openConnection();
                InputStream inputstream = connection.getInputStream();
                InputStreamReader read = new InputStreamReader(inputstream);
                int data = read.read();
                while(data !=-1){
                    char now = (char)data;
                    result +=now;
                    data = read.read();
                }
                return result;


            } catch (Exception e) {
                e.printStackTrace();
                return result;
            }



        }

        @SuppressLint("SetTextI18n")
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            tempera = (TextView)findViewById(R.id.temp);
            humi= (TextView)findViewById(R.id.humidity);
            pressu = (TextView)findViewById(R.id.pressure);
            windu = (TextView)findViewById(R.id.wind);
            descrip = (TextView)findViewById(R.id.description);
            back = (ImageView)findViewById(R.id.back);
            edit = (EditText)findViewById(R.id.name);
            go = (Button)findViewById(R.id.go);
            String sts = "";
            try {
                Log.i("Url",s);
                JSONObject obj = new JSONObject(s);
                String info1 = obj.getString("weather");
                String info2 = obj.getString("main");
                JSONObject obj1 = obj.getJSONObject("main");
                Log.i("weather",info1);
                Log.i("main",info2);

                String temp = obj1.getString("temp");
                String pressure = obj1.getString("pressure");
                String humidity= obj1.getString("humidity");
                Log.i("pressure",pressure);
                Log.i("humidity",humidity);
                String info3 = obj.getString("wind");
                JSONObject obj2 = obj.getJSONObject("wind");
                String wind = obj2.getString("speed");
                double celcius = (double) (Double.parseDouble(temp)-273.15);
                Log.i("temperature",Double.toString(celcius));
                tempera.setText(Double.toString(celcius));
                humi.setText(humidity);
                pressu.setText(pressure);
                windu.setText(wind);

                JSONArray arr1 = new JSONArray(info1);
                for(int i = 0;i < arr1.length();i++){
                    JSONObject re = arr1.getJSONObject(i);
                    Log.i("Size",Integer.toString(arr1.length()));
                    Log.i("mainIssue",re.getString("main"));
                    Log.i("Description",re.getString("description"));
                    descrip.setText(re.getString("description"));
                    sts = re.getString("main");
                    Log.i("main",sts);
                }
                if((sts.equals("Rain"))|| (sts.equals("rain"))){
                    back.animate().alpha(0).setDuration(1000);
                    back.setImageResource(R.drawable.rain);
                    back.animate().alpha(1);
                    edit.setBackgroundColor(Color.rgb(87,115,140));
                    descrip.setTextColor(Color.rgb(7,49,85));
                    descrip.setBackgroundColor(Color.rgb(87,115,140));
                }

                else if(celcius >32){
                    back.animate().alpha(0).setDuration(1000);
                    back.setImageResource(R.drawable.summer);
                    back.animate().alpha(1);
                    edit.setBackgroundColor(Color.rgb(205,163,110));
                    descrip.setTextColor(Color.rgb(244,216,149));
                    descrip.setBackgroundColor(Color.rgb(74,46,9));

                }
                else if(celcius<32){
                    back.animate().alpha(0).setDuration(1000);
                    back.setImageResource(R.drawable.cloud);
                    back.animate().alpha(1);
                    edit.setBackgroundColor(Color.rgb(205,163,110));
                    go.setBackgroundColor(Color.rgb(225,163,110));
                    descrip.setTextColor(Color.rgb(244,216,149));
                    descrip.setBackgroundColor(Color.rgb(74,46,9));

                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }
    public void clicked(View view){
        edit = (EditText)findViewById(R.id.name);
        String result = edit.getText().toString();
        DownloadJasonData data = new DownloadJasonData();
        data.execute("https://api.openweathermap.org/data/2.5/weather?q="+result+"&appid=00f642b9610d4a2f8c7230efcb19f864");
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }
}
