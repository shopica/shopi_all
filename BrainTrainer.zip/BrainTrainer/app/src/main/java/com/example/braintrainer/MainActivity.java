package com.example.braintrainer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Animation top,left;
    ImageView brain;
    TextView name,slogan;
    private int duration = 2500 ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);

        top = AnimationUtils.loadAnimation(this,R.anim.top_bot);
        left = AnimationUtils.loadAnimation(this,R.anim.left_right);

        brain = (ImageView)findViewById(R.id.brain);
        name = (TextView)findViewById(R.id.name);
        slogan = (TextView)findViewById(R.id.slogan);


        brain.setAnimation(top);
        name.setAnimation(left);
        slogan.setAnimation(left);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                Intent another = new Intent(MainActivity.this,SecondActivity.class);
                startActivity(another);
                finish();

            }
        },duration);

    }
}
