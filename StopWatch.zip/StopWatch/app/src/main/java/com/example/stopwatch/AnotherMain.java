package com.example.stopwatch;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

public class AnotherMain extends AppCompatActivity {
    SeekBar seek;
    TextView text;
    Button go;
    boolean buttonactive = false;
    CountDownTimer count;
    MediaPlayer audio;

    public void clicked(View view) {
        if (buttonactive == true) {
            go.setText("Go");
            seek.setEnabled(true);
            seek.setProgress(0);
            text.setText("00" + " : " + "00");
            buttonactive = false;
            count.cancel();
        }
        else {
            buttonactive = true;
            go = (Button) findViewById(R.id.result);
            go.setText("Reset");
            seek.setEnabled(false);
            count = new CountDownTimer(seek.getProgress() * 1000, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {

                    dothis((int) millisUntilFinished/1000);

                }

                @Override
                public void onFinish() {
                    go.setText("Go");
                    seek.setEnabled(true);
                    seek.setProgress(0);
                    text.setText("00" + " : " + "00");
                    buttonactive = false;
                    audio = MediaPlayer.create(getApplicationContext(),R.raw.horn);
                    audio.start();

                }
            }.start();

        }
    }
     public void dothis(int progress) {

        String min, sec;
        int minutes = progress / 60;
        int seconds = progress - (60 * minutes);
        if (minutes < 9 || seconds < 9) {
            if (minutes < 10) {
                min = "0" + Integer.toString(minutes);
            } else {
                min = Integer.toString(minutes);
            }
            if (seconds < 10) {
                sec = "0" + Integer.toString(seconds);
            } else {
                sec = Integer.toString(seconds);
            }

        } else {
            min = Integer.toString(minutes);
            sec = Integer.toString(seconds);

        }
        text.setText(min + " : " + sec);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_another_main);

        seek = (SeekBar)findViewById(R.id.seek);
        text =(TextView)findViewById(R.id.text);

        seek.setMax(600);
        seek.setProgress(60);

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    dothis(progress);


            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }

        });
    }



}
