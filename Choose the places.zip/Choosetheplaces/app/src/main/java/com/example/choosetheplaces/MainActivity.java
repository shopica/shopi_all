package com.example.choosetheplaces;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    static ArrayList<String> arr = new ArrayList<String>();
    static ArrayAdapter<String> adapter ;
    static ArrayList<LatLng> location = new ArrayList<LatLng>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView list = (ListView) findViewById(R.id.listView);
        arr.add("Add your Location");
        adapter = new ArrayAdapter<String>(this.getApplicationContext(), android.R.layout.simple_list_item_1,arr);
        location.add(new LatLng(0,0));
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent map = new Intent(getApplicationContext(),MapsActivity.class);
                map.putExtra("number",position);
                startActivity(map);

            }
        });

    }
}
